/* SPDX-License-Identifier: GPL-2.0-or-later */
/* 
 * Copyright (C) 2026 bmax121. All Rights Reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <zlib.h>
#include <sys/stat.h>
#include "bootimg.h"
#include "common.h"
#include "lib/lz4/lz4.h"
#include "lib/lz4/lz4frame.h"
#include "lib/lz4/lz4hc.h"
#include "lib/bz2/bzlib.h"
#include "lib/xz/xz.h"
#include "lib/sha/sha256.h"
#include "lib/sha/sha1.h"
// #include "lib/zstd/zstd.h"

_Static_assert(sizeof(struct avb_footer) == AVB_FOOTER_SIZE, "unexpected AVB footer layout");


static uint64_t XXH_swap64(uint64_t x) {
    return ((x << 56) & 0xff00000000000000ULL) |
           ((x << 40) & 0x00ff000000000000ULL) |
           ((x << 24) & 0x0000ff0000000000ULL) |
           ((x << 8)  & 0x000000ff00000000ULL) |
           ((x >> 8)  & 0x00000000ff000000ULL) |
           ((x >> 24) & 0x0000000000ff0000ULL) |
           ((x >> 40) & 0x000000000000ff00ULL) |
           ((x >> 56) & 0x00000000000000ffULL);
}

static uint32_t XXH_swap32(uint32_t x) {
    return ((x >> 24) & 0x000000FF) |
           ((x >>  8) & 0x0000FF00) |
           ((x <<  8) & 0x00FF0000) |
           ((x << 24) & 0xFF000000);
}

static uint32_t fdt32_to_cpu(uint32_t val) {
    return ((val << 24) & 0xff000000) |
           ((val << 8)  & 0x00ff0000) |
           ((val >> 8)  & 0x0000ff00) |
           ((val >> 24) & 0x000000ff);
}

/* AVB footer fields are big endian and unaligned; the footer struct keeps them
 * as byte arrays, so read and write them explicitly. */
static uint64_t avb_read_be64(const uint8_t *p) {
    uint64_t v;
    memcpy(&v, p, sizeof(v));
    return XXH_swap64(v);
}

static void avb_write_be64(uint8_t *p, uint64_t v) {
    v = XXH_swap64(v);
    memcpy(p, &v, sizeof(v));
}

static uint32_t avb_read_be32(const uint8_t *p) {
    uint32_t v;
    memcpy(&v, p, sizeof(v));
    return XXH_swap32(v);
}

void *memmem(const void *haystack, size_t haystacklen,
                       const void *needle, size_t needlelen) {
    if (needlelen == 0) return (void *)haystack;
    if (haystacklen < needlelen) return NULL;

    const char *h = (const char *)haystack;
    const char *n = (const char *)needle;
    size_t i;

    for (i = 0; i <= haystacklen - needlelen; i++) {
        if (h[i] == n[0] && memcmp(&h[i], n, needlelen) == 0) {
            return (void *)&h[i];
        }
    }
    return NULL;
}

int is_sha256(uint32_t id[8]) {
    if ((id[0] | id[1] | id[2] | id[3] | id[4] | id[5]) == 0) {
        return 1;
    }
    if (id[6] != 0 || id[7] != 0) {
        return 2;
    }
    
    return 0;
}

static int find_dtb_offset(const uint8_t *buf, unsigned int sz) {
    if (!buf || sz < sizeof(struct fdt_header)) return -1;
    const uint8_t *curr = buf;
    const uint8_t *end = buf + sz;

    while (curr < end - sizeof(struct fdt_header)) {
        curr = memmem(curr, end - curr, DTB_MAGIC, 4);
        if (curr == NULL) return -1;

        struct fdt_header *fdt_hdr = (struct fdt_header *)curr;
        uint32_t totalsize = fdt32_to_cpu(fdt_hdr->totalsize);
        uint32_t off_dt_struct = fdt32_to_cpu(fdt_hdr->off_dt_struct);
        if (totalsize > (uint32_t)(end - curr) || totalsize <= 0x48) {
            curr += 4;
            continue;
        }

        //  FDT_BEGIN_NODE (0x00000001)
        if (curr + off_dt_struct + 4 <= end) {
            uint32_t *tag = (uint32_t *)(curr + off_dt_struct);
            if (fdt32_to_cpu(*tag) == 0x00000001) {
                return (int)(curr - buf);
            }
        }
        curr += 4;
    }
    return -1;
}

int write_data_to_file(const char *path, const void *data, size_t size) {
    FILE *fp = fopen(path, "wb");
    if (!fp) return -1;
    fwrite(data, 1, size, fp);
    fclose(fp);
    chmod(path, 0644);
    return 0;
}

int compress_raw_deflate(const uint8_t *in_data, int in_len, uint8_t **out_data, int *out_len) {
    z_stream strm = {0};
    if (deflateInit2(&strm, 9, Z_DEFLATED, -MAX_WBITS, 8, Z_DEFAULT_STRATEGY) != Z_OK)
        return -1;

    uint32_t max_out_size = deflateBound(&strm, in_len);
    *out_data = malloc(max_out_size);
    if (!*out_data) { deflateEnd(&strm); return -1; }

    strm.next_in = (Bytef *)in_data;
    strm.avail_in = in_len;
    strm.next_out = *out_data;
    strm.avail_out = max_out_size;

    int ret = deflate(&strm, Z_FINISH);
    if (ret != Z_STREAM_END) {
        free(*out_data);
        *out_data = NULL;
        deflateEnd(&strm);
        return -2;
    }

    *out_len = strm.total_out;
    deflateEnd(&strm);
    return 0;
}

int compress_gzip(const uint8_t *in_data, size_t in_size, uint8_t **out_data, uint32_t *out_size) {
    z_stream strm = {0};
    if (deflateInit2(&strm, 9, Z_DEFLATED, 16 + MAX_WBITS, 8, Z_DEFAULT_STRATEGY) != Z_OK) 
        return -1;

    uint32_t max_out_size = deflateBound(&strm, in_size);
    *out_data = malloc(max_out_size);
    if (!*out_data) { deflateEnd(&strm); return -1; }

    strm.next_in = (Bytef *)in_data;
    strm.avail_in = in_size;
    strm.next_out = *out_data;
    strm.avail_out = max_out_size;

    int ret = deflate(&strm, Z_FINISH);
    if (ret != Z_STREAM_END) {
        free(*out_data);
        deflateEnd(&strm);
        return -2;
    }

    *out_size = strm.total_out;
    deflateEnd(&strm);
    return 0;
}
int decompress_gzip(const uint8_t *in_data, size_t in_size, const char *out_path) {
    z_stream strm = {0};
    strm.next_in = (Bytef *)in_data;
    strm.avail_in = in_size;

    if (inflateInit2(&strm, 16 + MAX_WBITS) != Z_OK) return -1;

    FILE *out = fopen(out_path, "wb");
    if (!out) { inflateEnd(&strm); return -1; }

    uint8_t out_buf[40960]; // 40KB buffer
    int ret;
    do {
        strm.next_out = out_buf;
        strm.avail_out = sizeof(out_buf);
        ret = inflate(&strm, Z_NO_FLUSH);
        if (ret < 0 && ret != Z_STREAM_END) {
            tools_logi("Error: Gzip inflate failed (err: %d)\n", ret);
            fclose(out);
            inflateEnd(&strm);
            return -2;
        }
        size_t have = sizeof(out_buf) - strm.avail_out;
        fwrite(out_buf, 1, have, out);
    } while (ret != Z_STREAM_END);

    fclose(out);
    chmod(out_path, 0644);
    inflateEnd(&strm);
    return 0;
}

static int decompress_gzip_to_mem(const uint8_t *in_data, size_t in_size, uint8_t **out_data, uint32_t *out_size)
{
    z_stream strm = { 0 };
    strm.next_in = (Bytef *)in_data;
    strm.avail_in = in_size;

    if (inflateInit2(&strm, 16 + MAX_WBITS) != Z_OK) return -1;

    size_t cap = 64 * 1024 * 1024;
    uint8_t *out = malloc(cap);
    if (!out) {
        inflateEnd(&strm);
        return -1;
    }
    size_t out_off = 0;

    uint8_t out_buf[40960]; // 40KB buffer
    int ret;
    do {
        strm.next_out = out_buf;
        strm.avail_out = sizeof(out_buf);
        ret = inflate(&strm, Z_NO_FLUSH);
        if (ret < 0 && ret != Z_STREAM_END) {
            tools_logi("Error: Gzip inflate failed (err: %d)\n", ret);
            free(out);
            inflateEnd(&strm);
            return -2;
        }
        size_t have = sizeof(out_buf) - strm.avail_out;
        if (out_off + have > cap) {
            size_t new_cap = cap * 2;
            while (new_cap < out_off + have) new_cap *= 2;
            uint8_t *tmp = realloc(out, new_cap);
            if (!tmp) {
                free(out);
                inflateEnd(&strm);
                return -1;
            }
            out = tmp;
            cap = new_cap;
        }
        memcpy(out + out_off, out_buf, have);
        out_off += have;
    } while (ret != Z_STREAM_END);

    inflateEnd(&strm);
    *out_data = out;
    *out_size = (uint32_t)out_off;
    return 0;
}

static int parse_lz4_header(const compress_head *head, LZ4F_preferences_t *prefs) {
    uint32_t magic = (head->magic[0] << 0) | (head->magic[1] << 8) | 
                     (head->magic[2] << 16) | (head->magic[3] << 24);
    if (magic != 0x184D2204) {
        return -1;
    }
    LZ4F_preferences_t tmp = LZ4F_INIT_PREFERENCES;
    *prefs = tmp;

    uint8_t flg = head->magic[4];
    prefs->frameInfo.blockMode = (flg & 0x20) ? LZ4F_blockIndependent : LZ4F_blockLinked;
    prefs->frameInfo.blockChecksumFlag = (flg & 0x10) ? 
                                         LZ4F_blockChecksumEnabled : LZ4F_noBlockChecksum;
    prefs->frameInfo.contentChecksumFlag = (flg & 0x08) ? 
                                           LZ4F_contentChecksumEnabled : LZ4F_noContentChecksum;
    

    uint8_t bd = head->magic[5];
    uint8_t block_size_id = (bd >> 4) & 0x07;
    switch (block_size_id) {
        case 4: prefs->frameInfo.blockSizeID = LZ4F_max64KB; break;
        case 5: prefs->frameInfo.blockSizeID = LZ4F_max256KB; break;
        case 6: prefs->frameInfo.blockSizeID = LZ4F_max1MB; break;
        case 7: prefs->frameInfo.blockSizeID = LZ4F_max4MB; break;
        default: return -2;
    }
    
    return 0;
}

int compress_lz4(const uint8_t *in_data, size_t in_size, 
                 uint8_t **out_data, uint32_t *out_size, 
                 compress_head k_head) {
    
    LZ4F_preferences_t prefs;
    int ret = parse_lz4_header(&k_head, &prefs);
    if (ret < 0) {
        return -3; 
    }
    

    size_t max_out_size = LZ4F_compressFrameBound(in_size, &prefs);
    
    *out_data = (uint8_t *)malloc(max_out_size);
    if (!*out_data) {
        return -1;
    }

    size_t compressed_size = LZ4F_compressFrame(*out_data, max_out_size, 
                                                in_data, in_size, &prefs);
    
    if (LZ4F_isError(compressed_size)) {
        free(*out_data);
        return -2;
    }
    
    *out_size = (uint32_t)compressed_size;
    return 0;
}
int compress_lz4_le(
    const uint8_t *in_data,
    size_t in_size,
    uint8_t **out_data,
    uint32_t *out_size,
    compress_head k_head
) {

    size_t max_blocks =
        (in_size + LZ4_BLOCK_SIZE - 1) / LZ4_BLOCK_SIZE;
    // uint32_t max_blocks_1 =
    //   ((uint32_t)k_head.magic[4])
    // | ((uint32_t)k_head.magic[5] << 8)
    // | ((uint32_t)k_head.magic[6] << 16)
    // | ((uint32_t)k_head.magic[7] << 24);
    tools_logi("Calculated max blocks: %zu\n", max_blocks);
    size_t max_out =
        sizeof(uint32_t) +                         // MAGIC
        max_blocks * (sizeof(uint32_t) +           // block header
        LZ4_compressBound(LZ4_BLOCK_SIZE));

    uint8_t *out = malloc(max_out);
    if (!out) {
        tools_loge("Failed to allocate memory for LZ4 compression,size: %zu\n",max_out);
        return -2;
    }

    size_t out_off = 0;

    /* write MAGIC */
    uint32_t magic = LZ4_MAGIC;
    memcpy(out + out_off, &magic, sizeof(magic));
    out_off += sizeof(magic);

    size_t in_off = 0;

    while (in_off < in_size) {
        size_t chunk_size = in_size - in_off;
        if (chunk_size > LZ4_BLOCK_SIZE)
            chunk_size = LZ4_BLOCK_SIZE;

        int max_dst = LZ4_compressBound((int)chunk_size);

        int compressed = LZ4_compress_HC(
            (const char *)(in_data + in_off),
            (char *)(out + out_off + sizeof(uint32_t)),
            (int)chunk_size,
            max_dst,
            LZ4HC_CLEVEL
        );

        if (compressed <= 0) {
            tools_loge("LZ4 compression failed for block at offset %zu\n", in_off);
            free(out);
            return -3;
        }

        /* write compressed block size */
        uint32_t csz = (uint32_t)compressed;
        memcpy(out + out_off, &csz, sizeof(csz));
        out_off += sizeof(uint32_t);

        /* advance over compressed data */
        out_off += compressed;
        in_off += chunk_size;
    }

    *out_data = out;
    *out_size = (uint32_t)out_off;
    return 0;
}

// int compress_zstd(const uint8_t *in_data, size_t in_size, uint8_t **out_data, uint32_t *out_size) {
//     size_t const max_out_size = ZSTD_compressBound(in_size);
//     *out_data = malloc(max_out_size);
//     if (!*out_data) return -1;
//     size_t const cSize = ZSTD_compress(*out_data, max_out_size, in_data, in_size, 3);

//     if (ZSTD_isError(cSize)) {
//         free(*out_data);
//         return -2;
//     }
//     *out_size = (uint32_t)cSize;
//     return 0;
// }
// int decompress_zstd(const uint8_t *src, size_t srcSize, uint8_t **dst, uint32_t *dstSize) {
//     unsigned long long const rSize = ZSTD_getFrameContentSize(src, srcSize);
//     if (rSize == ZSTD_CONTENTSIZE_ERROR) return -1;
//     if (rSize == ZSTD_CONTENTSIZE_UNKNOWN) return -2;

//     *dst = malloc((size_t)rSize);
//     if (!*dst) return -3;

//     size_t const dSize = ZSTD_decompress(*dst, (size_t)rSize, src, srcSize);

//     if (ZSTD_isError(dSize)) {
//         free(*dst);
//         return -4;
//     }
//     *dstSize = (uint32_t)dSize;
//     return 0;
// }

int decompress_xz(const uint8_t *src, size_t srcSize, uint8_t **dst, uint32_t *dstSize) {

    xz_crc32_init();


    struct xz_dec *s = xz_dec_init(XZ_SINGLE, 0);
    if (s == NULL) return -1;


    uint32_t dstCapacity = 128 * 1024 * 1024;
    *dst = (uint8_t *)malloc(dstCapacity);
    if (!*dst) {
        xz_dec_end(s);
        return -1;
    }

    struct xz_buf b;
    b.in = src;
    b.in_pos = 0;
    b.in_size = srcSize;
    b.out = *dst;
    b.out_pos = 0;
    b.out_size = dstCapacity;
    enum xz_ret ret = xz_dec_run(s, &b);

    if (ret != XZ_STREAM_END) {
        tools_loge("XZ Decompression failed: %d\n", ret);
        free(*dst);
        xz_dec_end(s);
        return -1;
    }

    *dstSize = (uint32_t)b.out_pos;
    xz_dec_end(s);
    return 0;
}

int decompress_lzma(const uint8_t *src, size_t srcSize, uint8_t **dst, uint32_t *dstSize) {
    xz_crc32_init();

    struct xz_dec *s = xz_dec_init(XZ_SINGLE, 0);
    if (!s) return -1;

    uint32_t dstCapacity = 128 * 1024 * 1024; 
    *dst = (uint8_t *)malloc(dstCapacity);
    if (!*dst) {
        xz_dec_end(s);
        return -1;
    }

    struct xz_buf b;
    b.in = src;
    b.in_pos = 0;
    b.in_size = srcSize;
    b.out = *dst;
    b.out_pos = 0;
    b.out_size = dstCapacity;

    enum xz_ret ret = xz_dec_run(s, &b);

    if (ret != XZ_STREAM_END) {
        tools_loge("Your xz-embedded version only supports XZ container (Method 6).\n");
        free(*dst);
        xz_dec_end(s);
        return -1;
    }

    *dstSize = (uint32_t)b.out_pos;
    xz_dec_end(s);
    return 0;
}

int auto_depress_to_mem(const uint8_t *data, size_t size, uint8_t **out_data, uint32_t *out_size, int *method_out)
{
    if (size < 4) return -1;
    *out_data = NULL;
    *out_size = 0;

    compress_head k_head;
    memcpy(&k_head, data, sizeof(k_head));
    int method = detect_compress_method(k_head);
    if (method_out) *method_out = method;
    tools_logi("Auto-detect compression method: %d\n", method);

    if (method == 1) { //Gzip
        tools_logi("Detected GZIP compressed kernel.\n");
        if (decompress_gzip_to_mem(data, size, out_data, out_size) == 0) {
            tools_logi(" Decompressed: %u bytes\n", *out_size);
            return 0;
        }
        tools_logi(" Gzip decompression failed.\n");
        return -1;
    }

    if (method == 2) {
        tools_logi(" Detected LZ4 Frame. Decompressing with lz4frame...\n");
        LZ4F_decompressionContext_t dctx;
        LZ4F_createDecompressionContext(&dctx, LZ4F_VERSION);

        size_t dstCapacity = 64 * 1024 * 1024;
        void *dst = malloc(dstCapacity);
        if (!dst) return -1;

        size_t consumedSize = size;
        size_t producedSize = dstCapacity;

        size_t ret = LZ4F_decompress(dctx, dst, &producedSize, data, &consumedSize, NULL);

        if (LZ4F_isError(ret)) {
            tools_loge("LZ4 Decompression failed: %s\n", LZ4F_getErrorName(ret));
            free(dst);
            LZ4F_freeDecompressionContext(dctx);
            return -1;
        }
        tools_logi("Decompressed: %zu bytes\n", producedSize);
        *out_data = dst;
        *out_size = (uint32_t)producedSize;
        LZ4F_freeDecompressionContext(dctx);
        return 0;
    }

    if (method == 3) {
        tools_logi("Probing LZ4 Legacy (block-based)...\n");

        const uint8_t *p   = (const uint8_t *)data;
        const uint8_t *end = p + size;

        if (size < 4)
            goto not_lz4;

        if (*(uint32_t *)p != LZ4_MAGIC)
            goto not_lz4;

        p += 4;

        size_t out_cap = 64 * 1024 * 1024;
        uint8_t *out = malloc(out_cap);
        if (!out)
            goto not_lz4;

        size_t out_off = 0;

        uint8_t *block_out = malloc(LZ4_BLOCK_SIZE);
        if (!block_out) {
            free(out);
            goto not_lz4;
        }

        int decoded_any = 0;
        while (1) {
            uint32_t block_size;

            if (p + 4 > end)
                break;

            memcpy(&block_size, p, 4);
            p += 4;

            if (block_size == 0)
                break;

            if (block_size > LZ4_compressBound(LZ4_BLOCK_SIZE))
                goto fail;

            if (p + block_size > end)
                goto fail;

            int decoded = LZ4_decompress_safe(
                (const char *)p,
                (char *)block_out,
                (int)block_size,
                LZ4_BLOCK_SIZE
            );

            if (decoded < 0)
                goto fail;

            decoded_any = 1;

            if (out_off + (size_t)decoded > out_cap) {
                size_t new_cap = out_cap * 2;
                while (new_cap < out_off + (size_t)decoded)
                    new_cap *= 2;

                uint8_t *tmp = realloc(out, new_cap);
                if (!tmp)
                    goto fail;

                out = tmp;
                out_cap = new_cap;
            }

            memcpy(out + out_off, block_out, (size_t)decoded);
            out_off += (size_t)decoded;

            p += block_size;
        }

        if (!decoded_any)
            goto fail;

        tools_logi("LZ4 block decompressed: %zu bytes\n", out_off);
        *out_data = out;
        *out_size = (uint32_t)out_off;
        free(block_out);
        return 0;

    fail:
        free(block_out);
        free(out);

    not_lz4:
        tools_logi("Not LZ4 block format, fallback.\n");
    }

    // till now no kernel use this
    // if (method == 4) { ... }

    if (method == 5) { // BZIP2
        tools_logi("Detected BZIP2. Decompressing...\n");

        unsigned int dstCapacity = 64 * 1024 * 1024;
        void *dst = malloc(dstCapacity);
        if (!dst) {
            tools_loge("Failed to allocate memory for BZIP2 decompression.\n");
            return -1;
        }

        unsigned int producedSize = dstCapacity;
        unsigned int consumedSize = (unsigned int)size;

        int ret = BZ2_bzBuffToBuffDecompress((char *)dst, &producedSize, (char *)data, consumedSize, 0, 0);

        if (ret != BZ_OK) {
            tools_loge(" BZIP2 Decompression failed with error code: %d\n", ret);
            free(dst);
            return -1;
        }

        tools_logi(" BZIP2 Decompressed: %u bytes\n", producedSize);
        *out_data = dst;
        *out_size = producedSize;
        return 0;
    }

    if (method == 6) { // XZ
        tools_logi(" Detected XZ format. Decompressing...\n");

        uint8_t *xz_dst = NULL;
        uint32_t xz_size = 0;

        if (decompress_xz(data, size, &xz_dst, &xz_size) == 0) {
            tools_logi("XZ Decompressed: %u bytes\n", xz_size);
            *out_data = xz_dst;
            *out_size = xz_size;
            return 0;
        }
        tools_loge(" XZ Decompression failed.\n");
        return -1;
    }

    if (method == 7) { // LZMA Legacy
        tools_logi("Detected Legacy LZMA format. Decompressing...\n");

        uint8_t *lzma_dst = NULL;
        uint32_t lzma_size = 0;

        if (decompress_lzma(data, size, &lzma_dst, &lzma_size) == 0) {
            tools_logi(" LZMA Decompressed: %u bytes\n", lzma_size);
            *out_data = lzma_dst;
            *out_size = lzma_size;
            return 0;
        }
        tools_loge(" LZMA Decompression failed.\n");
        return -1;
    }

    // raw kernel (or unknown format): hand back an owned copy
    tools_logi("Treating as Raw Kernel (or unknown format).\n");
    uint8_t *raw = malloc(size);
    if (!raw) return -1;
    memcpy(raw, data, size);
    *out_data = raw;
    *out_size = (uint32_t)size;
    return 0;
}

int auto_depress(const uint8_t *data, size_t size, const char *out_path) {
    uint8_t *out = NULL;
    uint32_t out_size = 0;
    int rc = auto_depress_to_mem(data, size, &out, &out_size, NULL);
    if (rc) return rc;
    write_data_to_file(out_path, out, out_size);
    free(out);
    return 0;
}

int extract_kernel(const char *bootimg_path) {
    FILE *fp = fopen(bootimg_path, "rb");
    if (!fp) {
        tools_logi("Error: Cannot open %s\n", bootimg_path);
        return -1;
    }
    
    struct boot_img_hdr hdr;
    fread(&hdr, sizeof(hdr), 1, fp);

    if (memcmp(hdr.magic, "ANDROID!", 8) != 0) {
        tools_logi("Error: Invalid boot image magic.\n");
        fclose(fp);
        return -2;
    }

    uint32_t page_size = hdr.page_size;
    uint32_t kernel_offset = page_size; // Kernel starts after the first page
    if (hdr.unused[0] >= 3) {
        kernel_offset = 4096;
    }
    if (hdr.unused[0] > 10) {
        kernel_offset = page_size;
    }

    tools_logi("Kernel size: %d,Header Version: %d, Offset: %d\n", hdr.kernel_size, hdr.unused[0], kernel_offset);

    uint8_t *kernel_data = malloc(hdr.kernel_size);
    if (!kernel_data) {
        fclose(fp);
        return -3;
    }

    fseek(fp, kernel_offset, SEEK_SET);
    fread(kernel_data, 1, hdr.kernel_size, fp);
    fclose(fp);

    int res = auto_depress(kernel_data, hdr.kernel_size, "kernel");

    free(kernel_data);
    return res;
}

int detect_compress_method(compress_head data) {
    // 1. GZIP / ZOPFLI (1F 8B)
    if (data.magic[0] == 0x1F && data.magic[1] == 0x8B) return 1;
    if (data.magic[0] == 0x1F && data.magic[1] == 0x9E) return 1;
    // 2. LZ4 (04 22 4D 18 is Frame )
    if (data.magic[0] == 0x04 && data.magic[1] == 0x22 && 
        data.magic[2] == 0x4D && data.magic[3] == 0x18) return 2;

    if (data.magic[0] == 0x03 && data.magic[1] == 0x21 && 
        data.magic[2] == 0x4C && data.magic[3] == 0x18) return 2;

    // LZ4 Legacy (02 21 4C 18)
    if (data.magic[0] == 0x02 && data.magic[1] == 0x21 && 
        data.magic[2] == 0x4C && data.magic[3] == 0x18) return 3;

    // 3. ZSTD  28 B5 2F FD
    if (data.magic[0] == 0x28 && data.magic[1] == 0xB5 && 
        data.magic[2] == 0x2F && data.magic[3] == 0xFD) return 4;

    // 4. BZIP2 (BZh) - 42 5A 68
    if (data.magic[0] == 0x42 && data.magic[1] == 0x5A && 
        data.magic[2] == 0x68) return 5;

    // 5. XZ - FD 37 7A 58 5A 00
    if (data.magic[0] == 0xFD && data.magic[1] == 0x37 && 
        data.magic[2] == 0x7A && data.magic[3] == 0x58) return 6;

    // 6. LZMA - 5D 00 00
    if (data.magic[0] == 0x5D && data.magic[1] == 0x00 && 
        data.magic[2] == 0x00) return 7;

    return 0; // Raw Kernel
}

/* Compare two equally sized ranges of two files.  Returns 0 when the ranges are
 * byte for byte identical. */
static int file_range_equal(const char *a_path, uint64_t a_offset, const char *b_path, uint64_t b_offset,
                            uint64_t size) {
    enum { chunk = 64 * 1024 };
    int rc = -1;
    uint8_t *a_buf = malloc(chunk);
    uint8_t *b_buf = malloc(chunk);
    FILE *a = fopen(a_path, "rb");
    FILE *b = fopen(b_path, "rb");
    if (!a_buf || !b_buf || !a || !b) goto out;
    if (fseek(a, (long)a_offset, SEEK_SET) != 0 || fseek(b, (long)b_offset, SEEK_SET) != 0) goto out;
    for (uint64_t done = 0; done < size; done += chunk) {
        size_t n = (size - done) < chunk ? (size_t)(size - done) : chunk;
        if (fread(a_buf, 1, n, a) != n || fread(b_buf, 1, n, b) != n) goto out;
        if (memcmp(a_buf, b_buf, n) != 0) goto out;
    }
    rc = 0;
out:
    if (a) fclose(a);
    if (b) fclose(b);
    free(a_buf);
    free(b_buf);
    return rc;
}

/*
 * Point the AVB footer of the repacked image at the metadata blob at its new
 * offset.  The blob must be byte for byte the one the original footer records:
 * a repack that truncated, dropped or rewrote it must not be signed off with a
 * footer that claims otherwise.  All other footer fields - including ones this
 * code does not know about - stay as copied from the original image, which
 * keeps the algorithm, rollback index and device properties untouched.
 */
static int avb_preserve_metadata(const char *orig_path, uint64_t orig_offset, const char *out_path,
                                 uint64_t out_offset, uint64_t size, uint64_t image_size) {
    if (file_range_equal(orig_path, orig_offset, out_path, out_offset, size) != 0) {
        tools_loge("AVB metadata at offset %llu was not preserved, refusing to point the footer at it\n",
                   (unsigned long long)out_offset);
        return -1;
    }

    FILE *out = fopen(out_path, "r+b");
    if (!out) {
        tools_loge("Cannot open %s to update the AVB footer\n", out_path);
        return -1;
    }

    struct avb_footer footer;
    int rc = -1;
    if (fseek(out, -(long)sizeof(footer), SEEK_END) == 0 && fread(&footer, sizeof(footer), 1, out) == 1 &&
        memcmp(footer.magic, AVB_FOOTER_MAGIC, sizeof(footer.magic)) == 0) {
        avb_write_be64(footer.image_size, image_size);
        avb_write_be64(footer.vbmeta_offset, out_offset);
        if (fseek(out, -(long)sizeof(footer), SEEK_END) == 0 && fwrite(&footer, sizeof(footer), 1, out) == 1) {
            rc = 0;
        }
    }
    fclose(out);

    if (rc) {
        tools_loge("Cannot update the AVB footer of %s\n", out_path);
    } else {
        tools_logi("- Preserved original AVB metadata at offset %llu\n", (unsigned long long)out_offset);
    }
    return rc;
}

int repack_bootimg_mem(const char *orig_boot_path,
                       const uint8_t *new_kernel, uint32_t new_kernel_size,
                       const char *out_boot_path) {
    tools_logi(" Starting automatic repack...\n");

    FILE *f_orig = fopen(orig_boot_path, "rb");
    if (!f_orig) return -1;

    struct boot_img_hdr hdr;
    struct avb_footer avb;
    uint32_t extracted_size = 0;
    fread(&hdr, sizeof(hdr), 1, f_orig);

    if (memcmp(hdr.magic, "ANDROID!", 8) != 0) {
        tools_logi("Not a valid Android Boot Image.\n");
        fclose(f_orig);
        return -2;
    }

    fseek(f_orig, 0, SEEK_END);
    long total_size = ftell(f_orig);

    // The AVB footer is the last sizeof(avb) bytes of the image.  Without its
    // magic the tail is opaque and is only copied back verbatim further down.
    memset(&avb, 0, sizeof(avb));
    int has_avb = 0;
    uint64_t old_vbmeta_offset = 0, old_vbmeta_size = 0;
    uint64_t new_image_size = 0, new_vbmeta_offset = 0;
    if (total_size >= (long)sizeof(avb) &&
        fseek(f_orig, total_size - (long)sizeof(avb), SEEK_SET) == 0 &&
        fread(&avb, sizeof(avb), 1, f_orig) == 1 &&
        memcmp(avb.magic, AVB_FOOTER_MAGIC, sizeof(avb.magic)) == 0) {
        has_avb = 1;
    }

    uint32_t header_ver = hdr.unused[0];
    if (header_ver > 10){header_ver = 0;extracted_size = hdr.unused[0];}
    uint32_t page_size = (header_ver >= 3) ? 4096 : hdr.page_size;
    uint32_t fmt_size =  (header_ver >= 3) ? hdr.kernel_addr : hdr.ramdisk_size;

    tools_logi("Header Version: %u, Page Size: %u, fmt_size: %u\n", header_ver, page_size,fmt_size);

    uint8_t *old_k_full = malloc(hdr.kernel_size);
    fseek(f_orig, page_size, SEEK_SET);
    fread(old_k_full, 1, hdr.kernel_size, f_orig);


    compress_head k_head;
    memcpy(&k_head, old_k_full, sizeof(k_head));
    int method = detect_compress_method(k_head);

    //  DTB (v1/v2)
    uint8_t *extracted_dtb = NULL;
    uint32_t dtb_size = 0;
    if (header_ver < 3) {
        int dtb_off = find_dtb_offset(old_k_full, hdr.kernel_size);
        if (dtb_off > 0) {
            dtb_size = hdr.kernel_size - dtb_off;
            extracted_dtb = malloc(dtb_size);
            memcpy(extracted_dtb, old_k_full + dtb_off, dtb_size);
            tools_logi("Detected DTB appended to kernel. Size: %u\n", dtb_size);
        }
    }
    free(old_k_full);

    uint8_t *raw_k_buf = (uint8_t *)new_kernel;
    uint32_t raw_k_size = new_kernel_size;

    uint8_t *final_k_buf = raw_k_buf;
    uint32_t final_k_size = raw_k_size;
    uint8_t *compressed_buf = NULL;

    if (method == 1) {
        tools_logi("Compressing new kernel with GZIP...\n");
        if (compress_gzip(raw_k_buf, raw_k_size, &compressed_buf, &final_k_size) == 0) {
            final_k_buf = compressed_buf;
        }
    }
    if (method == 2) {
        tools_logi("Compressing new kernel with LZ4...\n");
        if (compress_lz4(raw_k_buf, raw_k_size, &compressed_buf, &final_k_size, k_head) == 0) {
            final_k_buf = compressed_buf;
        }
    }
    if (method == 3) {
        tools_logi("Compressing new kernel with LZ4 Legacy...\n");
        if (compress_lz4_le(raw_k_buf, raw_k_size, &compressed_buf, &final_k_size, k_head) == 0) {
            final_k_buf = compressed_buf;
        }
    }
    if (method == 4) {
        tools_logi(" Kernel uses zstd, we have not supported it yet, please report to dev\n");
        return -1;
    }

    if (method == 5) { // BZIP2
        tools_logi(" Compressing new kernel with BZIP2 (Level 9)...\n");

        unsigned int max_out_size = (unsigned int)(raw_k_size * 1.01) + 600;
        compressed_buf = (uint8_t *)malloc(max_out_size);
        if (!compressed_buf) return -1;

        unsigned int final_size = max_out_size;
        unsigned int source_size = (unsigned int)raw_k_size;

        int ret = BZ2_bzBuffToBuffCompress((char*)compressed_buf, &final_size, (char*)raw_k_buf, source_size, 9, 0, 30);

        if (ret == BZ_OK) {
            final_k_buf = compressed_buf;
            final_k_size = final_size;
            tools_logi("BZIP2 compression complete. Size: %u bytes\n", final_k_size);
        } else {
            tools_loge("BZIP2 compression failed: %d\n", ret);
            free(compressed_buf);
            compressed_buf = NULL;
            return -1;
        }
    }
    if (method == 6 || method == 7) {
        tools_logi(" Original was XZ/LZMA. Repacking as GZIP for compatibility...\n");
        if (compress_gzip(raw_k_buf, raw_k_size, &compressed_buf, &final_k_size) == 0) {
            final_k_buf = compressed_buf;
            method = 1;
            tools_logi("Repacked as GZIP. New Size: %u bytes\n", final_k_size);
        } else {
            tools_loge("GZIP compression failed during XZ-to-GZIP conversion.\n");
            return -1;
        }
    }
    tools_logi("Final kernel size after compression (if applied): %u bytes\n", final_k_size);
    uint32_t old_k_aligned = ALIGN(hdr.kernel_size, page_size);
    uint32_t rest_data_offset = page_size + old_k_aligned;
    uint32_t rest_data_size = (total_size > rest_data_offset) ? (total_size - rest_data_offset) : 0;
    hdr.kernel_size = final_k_size + dtb_size;
    uint32_t new_k_total_aligned = ALIGN(hdr.kernel_size, page_size);
    uint32_t checksum_aligned = ALIGN(fmt_size , page_size);
    uint8_t *rest_buf_tmp = NULL;
    uint8_t *rest_buf = NULL;
    uint32_t rest_buf_offset  = 0;
    // The tail must be longer than the footer itself: the scan below starts at
    // rest_data_size - sizeof(avb) and has to stay inside the buffer.
    if (rest_data_size > sizeof(avb)) {
        // calloc so the last sizeof(avb) bytes (not read from file, they hold the
        // separate AVB footer) are deterministic instead of heap garbage
        rest_buf_tmp = calloc(1, rest_data_size);
        fseek(f_orig, rest_data_offset, SEEK_SET);
        fread(rest_buf_tmp, 1, rest_data_size-sizeof(avb), f_orig);
        for (int32_t i = (int32_t)(rest_data_size - sizeof(avb)) - 1; i >= 0; i--) {
            if (rest_buf_tmp[i] != 0) {
                rest_buf_offset = (uint32_t)(i + 1);
                break;
            }
        }
        if (rest_buf_offset > rest_data_size / 3 * 2){
            tools_logi("warning: overload size of rest data, kptools may crash,Rest data size: %u bytes, Actual used size: %u bytes\n", rest_data_size, rest_buf_offset);

            rest_buf = rest_buf_tmp;
            rest_data_size = rest_buf_offset + sizeof(avb);

        }else{
            rest_buf = malloc(rest_buf_offset);
            memcpy(rest_buf, rest_buf_tmp, rest_buf_offset);
            tools_logi("Rest data size: %u bytes, Actual used size: %u bytes\n", rest_data_size, rest_buf_offset);
            rest_data_size = rest_buf_offset;
            free(rest_buf_tmp);
        }

    }

    // The tail is written verbatim, so the output keeps the original image size
    // unless a bigger kernel pushes it past the old end of the image.
    if (rest_buf && page_size + (long)new_k_total_aligned + rest_data_size > total_size) {
        total_size = ALIGN(page_size + (long)new_k_total_aligned + rest_data_size, (long)page_size);
        tools_logi("Tail no longer fits, growing image to %ld bytes\n", total_size);
    }

    /*
     * Repacking only changes the padded kernel size, so everything behind the
     * kernel - the AVB metadata included - moves by that same delta.  Derive the
     * new metadata offset from the footer of the original image instead of
     * searching the image for an "AVB0" header: a boot image can contain more
     * than one (an embedded GKI certificate next to the metadata the device is
     * verified against) and only the footer says which one belongs to this
     * partition.  If the metadata cannot be located, or would not survive the
     * repack, fail before writing anything instead of pointing the output
     * footer at the wrong blob.
     */
    if (has_avb) {
        uint64_t old_image_size = avb_read_be64(avb.image_size);
        old_vbmeta_offset = avb_read_be64(avb.vbmeta_offset);
        old_vbmeta_size = avb_read_be64(avb.vbmeta_size);
        int64_t delta = (int64_t)new_k_total_aligned - (int64_t)old_k_aligned;
        uint64_t footer_offset = (uint64_t)total_size - sizeof(avb);
        uint8_t magic[4];
        const char *err = NULL;

        tools_logi("AVB footer: image_size=%llu, vbmeta_offset=%llu, vbmeta_size=%llu, shift=%lld\n",
                   (unsigned long long)old_image_size, (unsigned long long)old_vbmeta_offset,
                   (unsigned long long)old_vbmeta_size, (long long)delta);

        if (avb_read_be32(avb.version) != AVB_FOOTER_VERSION) {
            err = "unsupported AVB footer version";
        } else if (old_image_size < (uint64_t)page_size + old_k_aligned) {
            err = "AVB image_size does not cover the kernel";
        } else if (old_vbmeta_offset < old_image_size || old_vbmeta_offset > footer_offset) {
            err = "AVB vbmeta_offset points outside the image";
        } else if (old_vbmeta_size < AVB_VBMETA_MIN_SIZE ||
                   old_vbmeta_size > footer_offset - old_vbmeta_offset) {
            err = "AVB vbmeta_size does not fit the image";
        } else if (fseek(f_orig, (long)old_vbmeta_offset, SEEK_SET) != 0 ||
                   fread(magic, 1, sizeof(magic), f_orig) != sizeof(magic) ||
                   memcmp(magic, "AVB0", sizeof(magic)) != 0) {
            err = "AVB vbmeta_offset does not point at a vbmeta image";
        } else {
            new_image_size = (uint64_t)((int64_t)old_image_size + delta);
            new_vbmeta_offset = (uint64_t)((int64_t)old_vbmeta_offset + delta);
            if (new_image_size < (uint64_t)page_size + new_k_total_aligned) {
                err = "AVB image_size would not cover the repacked kernel";
            } else if (new_vbmeta_offset < new_image_size) {
                err = "AVB vbmeta_offset would precede the repacked image";
            } else if (new_vbmeta_offset > footer_offset ||
                       old_vbmeta_size > footer_offset - new_vbmeta_offset) {
                err = "AVB metadata would not fit the repacked image";
            }
        }

        if (err) {
            tools_loge("%s, refusing to write a broken AVB footer\n", err);
            fclose(f_orig);
            return -5;
        }
    }
    fclose(f_orig);

    uint32_t use_sha256 = is_sha256(hdr.id);
    int len = use_sha256 ? SHA256_BLOCK_SIZE : SHA1_BLOCK_SIZE;
    BYTE buf[len];
    if (use_sha256 != 1 || header_ver <= 3) {

        if (use_sha256){
            SHA256_CTX ctx;
            sha256_init(&ctx);
            sha256_update(&ctx, (const BYTE *)final_k_buf, hdr.kernel_size);
            sha256_update(&ctx, (const BYTE *)&hdr.kernel_size, 4);
            sha256_update(&ctx, (const BYTE *)rest_buf, fmt_size);
            sha256_update(&ctx, (const BYTE *)&fmt_size, sizeof(fmt_size));

            sha256_update(&ctx, (const BYTE *)rest_buf + checksum_aligned, hdr.second_size);
            sha256_update(&ctx, (const BYTE *)&hdr.second_size, 4);
            tools_logi("second_size=%d\n",hdr.second_size);
            if (hdr.second_size > 0){
                checksum_aligned += ALIGN(hdr.second_size , page_size);
            }
            //to do extra data
            if (extracted_size) {
                tools_logi("extracted_size=%d\n",extracted_size);
                sha256_update(&ctx, (const BYTE *)rest_buf + checksum_aligned, page_size);
                sha256_update(&ctx, (const BYTE *)&extracted_size, 4);
                checksum_aligned += ALIGN(extracted_size , page_size);
            }
            if (header_ver == 1 || header_ver == 2){
                tools_logi("recovery_dtbo_size=%d\n",hdr.recovery_dtbo_size);
                sha256_update(&ctx, (const BYTE *)rest_buf + checksum_aligned, hdr.recovery_dtbo_size);
                sha256_update(&ctx, (const BYTE *)&hdr.recovery_dtbo_size, 4);
                checksum_aligned += ALIGN(hdr.recovery_dtbo_size , page_size);
            }
            if (header_ver == 2){
                tools_logi("dtb_size=%d\n",hdr.dtb_size);
                sha256_update(&ctx, (const BYTE *)rest_buf + checksum_aligned, hdr.dtb_size);
                sha256_update(&ctx, (const BYTE *)&hdr.dtb_size, 4);
            }

            sha256_final(&ctx, buf);
            memcpy(hdr.id, buf, 32);
        }else{
            SHA1_CTX ctx;
            sha1_init(&ctx);
            sha1_update(&ctx, (const BYTE *)final_k_buf, hdr.kernel_size);
            sha1_update(&ctx, (const BYTE *)&hdr.kernel_size, 4);
            sha1_update(&ctx, (const BYTE *)rest_buf, fmt_size);
            sha1_update(&ctx, (const BYTE *)&fmt_size, sizeof(fmt_size));


            sha1_update(&ctx, (const BYTE *)rest_buf + checksum_aligned, hdr.second_size);
            sha1_update(&ctx, (const BYTE *)&hdr.second_size, 4);
            if (hdr.second_size > 0){
                checksum_aligned += ALIGN(hdr.second_size , page_size);
            }
            tools_logi("second_size=%d,offset=%d\n",hdr.second_size, checksum_aligned+rest_data_offset);
            //to do extra data
            if (extracted_size) {
                tools_logi("extracted_size=%d,offset=%d\n",extracted_size, checksum_aligned+rest_data_offset);
                sha1_update(&ctx, (const BYTE *)rest_buf + checksum_aligned, page_size);
                sha1_update(&ctx, (const BYTE *)&extracted_size, 4);
                checksum_aligned += ALIGN(extracted_size , page_size);
            }

            if (header_ver == 1 || header_ver == 2){
                tools_logi("recovery_dtbo_size=%d,offset=%d\n",hdr.recovery_dtbo_size, checksum_aligned+rest_data_offset);
                sha1_update(&ctx, (const BYTE *)rest_buf + checksum_aligned, hdr.recovery_dtbo_size);
                sha1_update(&ctx, (const BYTE *)&hdr.recovery_dtbo_size, 4);
                checksum_aligned += ALIGN(hdr.recovery_dtbo_size , page_size);
            }

            if (header_ver == 2){
                tools_logi("dtb_size=%d,dtb_addr=%lu\n",hdr.dtb_size,hdr.dtb_addr);
                sha1_update(&ctx, (const BYTE *)rest_buf + checksum_aligned, hdr.dtb_size);
                sha1_update(&ctx, (const BYTE *)&hdr.dtb_size, 4);
            }

            sha1_final(&ctx, buf);
            memcpy(hdr.id, buf, 20);
        }
    }
    FILE *f_out = fopen(out_boot_path, "wb");
    if (!f_out) { return -4; }


    fwrite(&hdr, sizeof(hdr), 1, f_out);
    fseek(f_out, page_size, SEEK_SET);


    fwrite(final_k_buf, 1, final_k_size, f_out);
    if (extracted_dtb) {
        fwrite(extracted_dtb, 1, dtb_size, f_out);
    }
    tools_logi("dtb_size=%d\n",dtb_size);

    fseek(f_out, page_size + new_k_total_aligned, SEEK_SET);

    if (rest_buf) {
        // write exactly the rest data; any slack up to total_size is zero-padded below
        fwrite(rest_buf, 1, rest_data_size, f_out);
    }

    long current_pos = ftell(f_out);

    //  Padding
    //tools_logi("current_post=%d,total_size=%d\n",current_pos,total_size);
    long footer_pos = total_size - (long)sizeof(avb);
    int footer_written = 0;
    if (current_pos <= footer_pos) {
        long padding = footer_pos - current_pos;
        if (padding > 0) {
            uint8_t *zero_pad = calloc(1, padding);
            fwrite(zero_pad, 1, padding, f_out);
            free(zero_pad);
        }
        // Footer of the original image, copied byte for byte.  Its pointers are
        // rewritten below, once the metadata is confirmed to be intact at its
        // new offset.
        fwrite(&avb, 1, sizeof(avb), f_out);
        footer_written = 1;
    } else {
        tools_loge("Repacked image ends at %ld, no room for the AVB footer at %ld\n", current_pos, footer_pos);
    }

    fclose(f_out);
    if (compressed_buf) free(compressed_buf);
    if (extracted_dtb) free(extracted_dtb);
    if (rest_buf) free(rest_buf);

    if (has_avb) {
        if (!footer_written) return -6;
        // Fail rather than point the footer at a metadata blob that the repack
        // did not preserve: an image with a wrong footer is rejected by AVB, and
        // a flashed one would be unusable.
        int rc = avb_preserve_metadata(orig_boot_path, old_vbmeta_offset, out_boot_path, new_vbmeta_offset,
                                       old_vbmeta_size, new_image_size);
        if (rc) return rc;
    }

    tools_logi("Repack completed: %s\n", out_boot_path);
    return 0;
}

int repack_bootimg(const char *orig_boot_path,
                   const char *new_kernel_path,
                   const char *out_boot_path) {
    FILE *f_new_k = fopen(new_kernel_path, "rb");
    if (!f_new_k) {
        tools_loge("Cannot open new kernel %s\n", new_kernel_path);
        return -3;
    }
    fseek(f_new_k, 0, SEEK_END);
    long raw_k_size = ftell(f_new_k);
    fseek(f_new_k, 0, SEEK_SET);
    uint8_t *raw_k_buf = malloc(raw_k_size);
    if (!raw_k_buf) {
        fclose(f_new_k);
        return -3;
    }
    fread(raw_k_buf, 1, raw_k_size, f_new_k);
    fclose(f_new_k);

    int rc = repack_bootimg_mem(orig_boot_path, raw_k_buf, (uint32_t)raw_k_size, out_boot_path);
    free(raw_k_buf);
    return rc;
}

int is_bootimg(const char *path)
{
    FILE *fp = fopen(path, "rb");
    if (!fp) return 0;
    char magic[8];
    size_t n = fread(magic, 1, sizeof(magic), fp);
    fclose(fp);
    return n == sizeof(magic) && !memcmp(magic, "ANDROID!", 8);
}

int patch_bootimg(const char *bootimg_path, const char *kpimg_path, const char *out_boot_path,
                  const char *superkey, bool root_key, const char **additional,
                  extra_config_t *extra_configs, int extra_config_num)
{
    set_log_enable(true);
    tools_logi("patch boot image: %s\n", bootimg_path);

    if (!kpimg_path) tools_loge_exit("empty kpimg\n");
    if (!out_boot_path) tools_loge_exit("empty out image path\n");
    if (!superkey && !root_key) tools_loge_exit("empty superkey\n");

    // read the compressed kernel segment from the boot image
    FILE *fp = fopen(bootimg_path, "rb");
    if (!fp) {
        tools_loge("Cannot open %s\n", bootimg_path);
        return -1;
    }

    struct boot_img_hdr hdr;
    fread(&hdr, sizeof(hdr), 1, fp);

    if (memcmp(hdr.magic, "ANDROID!", 8) != 0) {
        tools_loge("Invalid boot image magic.\n");
        fclose(fp);
        return -2;
    }

    uint32_t page_size = hdr.page_size;
    uint32_t kernel_offset = page_size; // Kernel starts after the first page
    if (hdr.unused[0] >= 3) {
        kernel_offset = 4096;
    }
    if (hdr.unused[0] > 10) {
        kernel_offset = page_size;
    }

    tools_logi("Kernel size: %u, Header Version: %u, Offset: %u\n", hdr.kernel_size, hdr.unused[0], kernel_offset);

    uint8_t *compressed = malloc(hdr.kernel_size);
    if (!compressed) {
        fclose(fp);
        return -3;
    }
    fseek(fp, kernel_offset, SEEK_SET);
    fread(compressed, 1, hdr.kernel_size, fp);
    fclose(fp);

    // decompress the kernel into memory
    uint8_t *raw = NULL;
    uint32_t raw_size = 0;
    int rc = auto_depress_to_mem(compressed, hdr.kernel_size, &raw, &raw_size, NULL);
    free(compressed);
    if (rc) {
        tools_loge("decompress kernel failed\n");
        return -4;
    }

    // patch the kernel in memory (patch_update_img_buf owns nothing of the input)
    char *patched = NULL;
    int patched_len = 0;
    rc = patch_update_img_buf((const char *)raw, (int)raw_size, kpimg_path, superkey, root_key,
                              additional, extra_configs, extra_config_num, &patched, &patched_len);
    free(raw);
    if (rc) {
        tools_loge("patch kernel failed\n");
        return -5;
    }

    // recompress with the original method and write the new boot image
    rc = repack_bootimg_mem(bootimg_path, (const uint8_t *)patched, (uint32_t)patched_len, out_boot_path);

    free(patched);
    set_log_enable(false);
    return rc;
}

int cacluate_sha1(const char *file) {
    FILE *fp = fopen(file, "rb");
    if (!fp) {
        return -1;
    }
    SHA1_CTX ctx;
    sha1_init(&ctx);

    uint8_t *buffer = malloc(409600);
    size_t bytesRead;
    while ((bytesRead = fread(buffer, 1, sizeof(buffer), fp)) > 0) {
        sha1_update(&ctx, buffer, bytesRead);
    }
    fclose(fp);
    uint8_t hash[SHA1_BLOCK_SIZE];
    sha1_final(&ctx, hash);
    free(buffer);
    for (int i = 0; i < 20; i++) { 
        printf("%02x", hash[i]);
    }
    return 0;
}
